document.getElementById('userForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio do formulário padrão

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const messageElement = document.getElementById('message');

    // Validação simples de preenchimento
    if (!name || !email) {
        alert('Por favor, preencha todos os campos.');
        return;
    }

    // Validação de e-mail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Por favor, insira um e-mail válido.');
        return;
    }

    // Exibir mensagem de sucesso
    messageElement.textContent = 'Cadastro concluído com sucesso.';
    messageElement.classList.remove('hidden');

    // Simulação de inserção na base de dados (pode ser substituído por chamada ao backend)
    console.log(`Usuário cadastrado: Nome - ${name}, Email - ${email}`);

    // Limpar campos do formulário
    document.getElementById('userForm').reset();
});
