document.addEventListener('DOMContentLoaded', function() {
    // Simulação de recuperação de usuários da "base de dados"
    const users = ['Usuário A', 'Usuário B', 'Usuário C', 'Usuário D']; // Substitua com dados reais em caso de uso com backend

    const userSelect = document.getElementById('user');
    users.forEach(user => {
        const option = document.createElement('option');
        option.value = user;
        option.textContent = user;
        userSelect.appendChild(option);
    });

    document.getElementById('taskForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        const description = document.getElementById('description').value.trim();
        const sector = document.getElementById('sector').value.trim();
        const user = document.getElementById('user').value;
        const priority = document.getElementById('priority').value;
        const messageElement = document.getElementById('message');

        // Validação simples de preenchimento
        if (!description || !sector || !user || !priority) {
            alert('Por favor, preencha todos os campos.');
            return;
        }

        // Exibir mensagem de sucesso
        messageElement.textContent = 'Cadastro concluído com sucesso.';
        messageElement.classList.remove('hidden');

        // Simulação de inserção na base de dados (pode ser substituído por chamada ao backend)
        console.log(`Tarefa cadastrada: Descrição - ${description}, Setor - ${sector}, Usuário - ${user}, Prioridade - ${priority}`);

        // Limpar campos do formulário
        document.getElementById('taskForm').reset();
    });
});
